import { EmergencyRequest } from "./EmergencyRequest";

export class EmergencyRequestStatus extends EmergencyRequest {

    private statusName: string; 

    constructor () {
        super()
    }

    getStatusName():string {
        return this.statusName; 
    }



}