

export class EmergencyRequest{

    protected request_time: Date; 
    protected latitude: string; 
    protected longitude: string;
    protected notification_message: string; 
    protected userId: number; 
    protected statusId: number; 

    constructor(){}


    getRequestTime(): Date{
        return this.request_time; 
    }

    getLatitude(): string {
        return this.latitude; 
    }

    getLongitude(): string {
        return this.longitude; 
    }

    getNotificationMessage():string {
        return this.notification_message;
    }

    getUserId():number{
        return this.userId; 
    }

    getStatusId(): number {
        return this.statusId;
    }



}



