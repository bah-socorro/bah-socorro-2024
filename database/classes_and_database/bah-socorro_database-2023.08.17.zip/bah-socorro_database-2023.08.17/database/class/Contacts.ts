export class Contacts { 

    private userId:number; 
    constructor (
        private contact_name: string, 
        private contact_phone: string, 
        private contact_type: string
    )
    {

    }


    getContactName(): string {
        return this.contact_name;
    }

    getContactPhone(): string { 
        return this.contact_phone; 
    }

    getContactType(): string {
        return this.contact_type; 
    }

    getUserId(): number {
        return this.userId; 
    }
    
}