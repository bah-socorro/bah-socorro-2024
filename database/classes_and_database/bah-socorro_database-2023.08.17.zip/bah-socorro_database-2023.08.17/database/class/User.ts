export class User {



    constructor(

        private user_name: string,
        private address: string,
        private phone_number: string,
        private cpf: string,
        private registration_date: Date

    ) {

    }




    getName(): string {
        return this.user_name;
    }

    getAdress(): string {
        return this.address;
    }

    getPhoneNumber(): string {
        return this.phone_number;
    }

    getCpf(): string {
        return this.cpf
    }

    getRegistrationDate(): Date {
        return this.registration_date;
    }



}